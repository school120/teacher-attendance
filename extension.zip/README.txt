Frisch Veracross Auto Check-in (Chrome/Edge Extension)
=====================================================

What it does
------------
- Runs on https://checkin.veracross.com/*
- If the page URL contains ?legacy=########## (or #legacy=##########):
    1) Fills the "School Student ID" field (#legacy_id)
    2) Clicks the "Scan Here" button
    3) Waits for the success message inside #checkin_response
    4) Closes the tab automatically

Install
-------
1) Open Chrome or Edge and go to: chrome://extensions
2) Toggle "Developer mode" (top-right)
3) Click "Load unpacked" and select this folder.
   (If you downloaded the .zip first, unzip it somewhere, then select the unzipped folder.)

Use
---
From your attendance web app, open this URL in a new tab/window:
  https://checkin.veracross.com/frisch/kiosk/entrance?legacy=1139575041

The extension will auto-fill, submit, wait for the response, then close the tab.
If there's an error (e.g., invalid ID), the tab stays open so the guard can read it.

Notes
-----
- Make sure the selector IDs on the kiosk page remain:
    #legacy_id, #checkin (form), #sign_in_button input[type=submit], #checkin_response
  If Veracross changes their markup, update content.js selectors accordingly.
- You can test by manually typing a 10-digit legacy ID at the end of the URL.
- The extension requires no special permissions beyond host access to the kiosk domain.
