// Runs on https://checkin.veracross.com/*
// Behavior:
// 1) If URL includes ?legacy=########## or #legacy=##########, auto submit.
// 2) Fill #legacy_id, click the submit, wait for success in #checkin_response.
// 3) On success, try window.close(); if blocked, navigate away to about:blank.

(function() {
  const LEGACY = getLegacyFromUrl();
  if (!LEGACY) return; // do nothing if no legacy code present

  // Some kiosks load jquery+turbolinks; give it a moment:
  ready(() => {
    injectAndSubmit(LEGACY);
  });

  function getLegacyFromUrl() {
    try {
      const u = new URL(window.location.href);
      const q = u.searchParams.get('legacy');
      if (q && /^\d{10}$/.test(q)) return q;
      // also allow hash format: #legacy=##########
      const m = (u.hash || '').match(/legacy=(\d{10})/);
      return m ? m[1] : null;
    } catch {
      const m = String(window.location.href).match(/legacy=(\d{10})/);
      return m ? m[1] : null;
    }
  }

  function ready(fn){
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      setTimeout(fn, 0);
    } else {
      document.addEventListener('DOMContentLoaded', fn);
    }
  }

  function injectAndSubmit(legacy) {
    const input = document.querySelector('#legacy_id');
    const form  = document.querySelector('#checkin');
    const btn   = document.querySelector('#sign_in_button input[type=submit], #checkin input[type=submit]');
    if (!input || !form || !btn) {
      // retry a few times in case kiosk JS replaced the DOM
      retry(() => injectAndSubmit(legacy));
      return;
    }

    // Fill the field "like a human"
    input.focus();
    input.value = legacy;

    // Click submit
    btn.click();

    // Watch for response success
    waitForSuccess(legacy);
  }

  function waitForSuccess(legacy) {
    const resp = document.querySelector('#checkin_response');
    if (!resp) {
      retry(() => waitForSuccess(legacy));
      return;
    }

    const checkNow = () => {
      const html = (resp.innerHTML || '').toLowerCase();
      const ok = html.includes('successfully') || html.includes('late arrival successfully logged') ||
                 resp.querySelector('.success');
      const bad = html.includes('invalid') || html.includes('not found') || html.includes('error') || html.includes('failed');
      if (ok) {
        closeSoon();
        return true;
      }
      if (bad) {
        // Leave the tab open so the guard can see the message.
        return true;
      }
      return false;
    };

    if (checkNow()) return;

    const mo = new MutationObserver(() => {
      if (checkNow()) { mo.disconnect(); }
    });
    mo.observe(resp, { childList: true, subtree: true, characterData: true });

    // Safety timeout: if nothing appears after 8s, close anyway
    setTimeout(closeSoon, 8000);
  }

  function closeSoon(){
    setTimeout(() => {
      // First try to close
      window.close();
      // If not allowed, navigate away so tab becomes empty
      setTimeout(() => { try { location.replace('about:blank'); } catch(_) {} }, 200);
    }, 700);
  }

  let tries = 0;
  function retry(fn){
    tries += 1;
    if (tries > 12) return; // ~6s total
    setTimeout(fn, 500);
  }
})();
