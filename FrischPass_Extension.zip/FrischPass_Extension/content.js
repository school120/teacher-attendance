// v20: 62x100mm, left‑aligned, no outer padding. Logo is a true centered watermark:
// - drawn with 'contain' scaling to preserve aspect ratio
// - opacity 0.35 (lighter watermark)
// - never cropped or squashed
// - no left-column mask; instead add a thin white outline to text for legibility
const DEFAULTS = {
  rosterUrl: "https://school120.github.io/FrischPass/roster.csv",
  logoUrl: "https://school120.github.io/FrischPass/logo.png",
  labelLenMM: 100,
  labelWidthMM: 62,
  dpi: 300,
  printScale: 0.96
};

function getSettings() {
  return new Promise(res => chrome.storage.sync.get(DEFAULTS, v => res(Object.assign({}, DEFAULTS, v||{}))));
}

function normHeader(s){
  return String(s||"").toLowerCase().replace(/^\uFEFF/,'').replace(/[^a-z0-9]+/g,' ').trim();
}

// CSV → Map(legacyId -> {name, grade})
const roster = new Map();
function parseCSV(text) {
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const rows=[]; let i=0,cur='',row=[],q=false;
  while(i<text.length){const c=text[i];
    if(q){ if(c=='"'){ if(text[i+1]=='"'){cur+='"';i++;} else q=false; } else cur+=c; }
    else { if(c=='"') q=true; else if(c==','){row.push(cur);cur='';} else if(c=='\n'){row.push(cur);rows.push(row);row=[];cur='';} else if(c=='\r'){} else cur+=c; }
    i++;
  }
  if(cur.length||row.length){ row.push(cur); rows.push(row); }
  return rows;
}
async function loadRoster(url){
  try{
    const r = await fetch(url, {cache:"no-store"}); if(!r.ok) return;
    let txt = await r.text();
    const rows = parseCSV(txt).filter(r=>r.length && r.join('').trim()!=='');
    if (!rows.length) return;
    const header = rows[0].map(x=>normHeader(x));
    const iId = header.findIndex(h => /legacy.*student.*id/.test(h) || h==="legacy student id" || h==="legacy id" || h==="student id");
    const iName = header.findIndex(h => /full.*name/.test(h) || h==="name" || h==="student name");
    const iGrade = header.findIndex(h => /current.*grade/.test(h) || h==="grade" || h==="current grade");
    if (iId < 0 || iName < 0) return;
    for (let k=1;k<rows.length;k++){
      const rr = rows[k];
      const rawId = (rr[iId]||"").toString().trim();
      if (!rawId) continue;
      const id = rawId.replace(/\s+/g, '');
      const name = (rr[iName]||"").toString().trim();
      const grade = iGrade>=0 ? (rr[iGrade]||"").toString().trim() : "";
      roster.set(id, {name, grade});
    }
  }catch(e){ console.warn("Roster load error", e); }
}

function mmToPx(mm, dpi){ return Math.max(1, Math.round(mm/25.4*dpi)); }

function wrapLines(ctx, text, maxWidth, lineHeight){
  const words = String(text).split(/\s+/);
  let line = '', out = [];
  for (let n=0;n<words.length;n++){
    const test = line ? line + ' ' + words[n] : words[n];
    const w = ctx.measureText(test).width;
    if (w > maxWidth && line){
      out.push(line); line = words[n];
    } else {
      line = test;
    }
  }
  if (line) out.push(line);
  const height = out.length * lineHeight;
  return {lines: out, height};
}

async function drawLabelToCanvas({name, grade, logoUrl, wMM, hMM, dpi}){
  const wpx = mmToPx(wMM, dpi);
  const hpx = mmToPx(hMM, dpi);
  const c = document.createElement('canvas');
  c.width = wpx; c.height = hpx;
  const ctx = c.getContext('2d');
  ctx.fillStyle = "#fff"; ctx.fillRect(0,0,wpx,hpx);

  // --- Watermark (centered 'contain', aspect preserved) ---
  if (logoUrl) {
    try {
      const img = await new Promise((resolve)=>{
        const im = new Image(); im.crossOrigin = "anonymous";
        im.onload = ()=>resolve(im); im.onerror = ()=>resolve(null); im.src = logoUrl;
      });
      if (img){
        // Target box is 70% of canvas in both dimensions, but use 'contain' to preserve aspect
        const maxW = Math.floor(wpx * 0.70);
        const maxH = Math.floor(hpx * 0.70);
        const scale = Math.min(maxW / img.width, maxH / img.height);
        const w = Math.floor(img.width * scale);
        const h = Math.floor(img.height * scale);
        const x = Math.floor((wpx - w)/2);
        const y = Math.floor((hpx - h)/2);
        const prev = ctx.globalAlpha;
        ctx.globalAlpha = 0.35; // lighter watermark
        ctx.drawImage(img, x, y, w, h);
        ctx.globalAlpha = prev;
      }
    } catch(e){}
  }

  // --- Text column: left aligned, no outer padding, but add small inner margin to avoid top edge cut ---
  const mm = (v)=> Math.round(v/25.4*dpi);
  const x0 = mm(2.5);                 // tiny leading margin (visual; avoids hard edge)
  const maxText = wpx - mm(5);        // keep a small right margin so long names don't clip
  let y = mm(4);                      // small top margin

  // Typography tuned for visual hierarchy
  const fTitle = mm(6.0);
  const fName  = mm(5.4);
  const fMinor = mm(4.4);
  const lhTitle= Math.round(fTitle * 1.06);
  const lhName = Math.round(fName  * 1.10);
  const lhMinor= Math.round(fMinor * 1.14);
  ctx.textBaseline = "top";
  ctx.fillStyle = "#000";

  function drawOutlinedLine(text, x, y, font){
    ctx.font = font;
    // thin white outline to stand off watermark
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#fff";
    ctx.strokeText(text, x, y);
    ctx.fillText(text, x, y);
  }

  // Title (two lines if needed)
  ctx.font = `bold ${fTitle}px Arial`;
  const titleWrap = wrapLines(ctx, "FRISCHPASS – EARLY DISMISSAL", maxText - x0, lhTitle);
  titleWrap.lines.forEach(line => { drawOutlinedLine(line, x0, y, `bold ${fTitle}px Arial`); y += lhTitle; });
  y += mm(1.2);

  // Name
  const nameWrap = wrapLines(ctx, name||"Unknown Student", maxText - x0, lhName);
  nameWrap.lines.forEach(line => { drawOutlinedLine(line, x0, y, `bold ${fName}px Arial`); y += lhName; });

  // Grade (full string)
  if (grade) {
    y += mm(1.2);
    const gradeWrap = wrapLines(ctx, String(grade), maxText - x0, lhMinor);
    gradeWrap.lines.forEach(line => { drawOutlinedLine(line, x0, y, `${fMinor}px Arial`); y += lhMinor; });
  }

  // Time
  y += mm(1.2);
  const timeStr = "Signed out: " + new Date().toLocaleString();
  const timeWrap = wrapLines(ctx, timeStr, maxText - x0, lhMinor);
  timeWrap.lines.forEach(line => { drawOutlinedLine(line, x0, y, `${fMinor}px Arial`); y += lhMinor; });

  return c;
}

function printCanvasAsImage(canvas, wMM, hMM, scale){
  const iframe = document.createElement('iframe');
  iframe.style.position='fixed'; iframe.style.left='-9999px'; iframe.style.width='0'; iframe.style.height='0';
  document.documentElement.appendChild(iframe);
  const doc = iframe.contentDocument || iframe.contentWindow.document;
  const dataURL = canvas.toDataURL('image/png');
  const wIn = (wMM/25.4*scale).toFixed(3);
  const hIn = (hMM/25.4*scale).toFixed(3);
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Label</title>
    <style>
      @media print { html,body{ -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
      html,body{ margin:0; padding:0; }
      .wrap{ width:${wIn}in; min-height:${hIn}in; display:flex; align-items:flex-start; justify-content:flex-start; }
      img{ width:${wIn}in; height:auto; display:block; }
    </style></head><body><div class="wrap"><img src="${dataURL}" alt=""></div></body></html>`;
  doc.open(); doc.write(html); doc.close();
  const go=()=>{ try{ iframe.contentWindow.focus(); iframe.contentWindow.print(); } finally { setTimeout(()=>iframe.remove(), 1500);} };
  if (doc.readyState==='complete') setTimeout(go,100); else iframe.addEventListener('load',()=>setTimeout(go,100));
}

(async function attach(){
  const settings = await getSettings();
  await loadRoster(settings.rosterUrl);

  const input = document.getElementById('legacy_id');
  if (!input) { setTimeout(attach, 300); return; }

  // keep focus for scanner
  const focusIv = setInterval(()=>{ if(document.activeElement!==input) input.focus(); }, 250);
  window.addEventListener('beforeunload',()=>clearInterval(focusIv));

  // auto-submit on scan/enter
  function ujsSubmit(form){
    const btn = form.querySelector('input[type="submit"],button[type="submit"]');
    if (btn) { btn.click(); return; }
    const ev = new Event('submit', {bubbles:true, cancelable:true}); form.dispatchEvent(ev);
  }
  function handleSubmit(){
    const id = (input.value||'').trim(); if(!id) return;
    input.dataset.pendingId = id.replace(/\s+/g,'');
    if (input.form) ujsSubmit(input.form);
  }
  input.addEventListener('keydown',(e)=>{
    if(e.key==='Enter'){ e.preventDefault(); handleSubmit(); }
    else { clearTimeout(input._deb); input._deb=setTimeout(handleSubmit,250); }
  }, true);

  // detect success banner
  const container = document.querySelector('#checkin_response');
  let printedForId = '';
  async function checkAndPrint(){
    if(!container) return;
    const s = container.querySelector('.success');
    if(!s) return;
    const shown = getComputedStyle(s).display!=='none';
    if(!shown) return;
    const id = input.dataset.pendingId||'';
    if(!id || id===printedForId) return;
    printedForId = id;

    const info = roster.get(id) || {name:'Unknown Student', grade:''};
    const canvas = await drawLabelToCanvas({
      name: info.name,
      grade: info.grade,
      logoUrl: settings.logoUrl,
      wMM: settings.labelWidthMM,
      hMM: settings.labelLenMM,
      dpi: settings.dpi
    });
    printCanvasAsImage(canvas, settings.labelWidthMM, settings.labelLenMM, settings.printScale);

    input.value=''; input.focus(); input.dataset.pendingId='';
    setTimeout(()=>{ printedForId=''; }, 1000);
  }
  if (container){ const obs = new MutationObserver(checkAndPrint); obs.observe(container,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']}); }
  else { setInterval(checkAndPrint, 300); }
})();