const DEFAULTS = {
  rosterUrl: "https://docs.google.com/spreadsheets/d/1ic8ou85wXm1F7BVQ79wPmCRD6FNTRcw8ov9UiJ2Z5LY/export?format=csv",
  logoUrl: chrome.runtime.getURL("logo.png"),
  labelLenMM: 100,
  labelWidthMM: 62,
  dpi: 300,
  printScale: 0.96
};
const rosterUrl = document.getElementById('rosterUrl');
const logoUrl = document.getElementById('logoUrl');
const labelLenMM = document.getElementById('labelLenMM');
const labelWidthMM = document.getElementById('labelWidthMM');
const dpi = document.getElementById('dpi');
const printScale = document.getElementById('printScale');
const saveBtn = document.getElementById('save');

chrome.storage.sync.get(DEFAULTS, v => {
  rosterUrl.value = v.rosterUrl;
  logoUrl.value = v.logoUrl;
  labelLenMM.value = v.labelLenMM;
  labelWidthMM.value = v.labelWidthMM;
  dpi.value = v.dpi;
  printScale.value = v.printScale;
});

saveBtn.addEventListener('click', () => {
  const payload = {
    rosterUrl: (rosterUrl.value || DEFAULTS.rosterUrl).trim(),
    logoUrl: (logoUrl.value || DEFAULTS.logoUrl).trim(),
    labelLenMM: Math.max(70, Math.min(200, parseInt(labelLenMM.value,10) || DEFAULTS.labelLenMM)),
    labelWidthMM: Math.max(56, Math.min(62, parseInt(labelWidthMM.value,10) || DEFAULTS.labelWidthMM)),
    dpi: Math.max(200, Math.min(300, parseInt(dpi.value,10) || DEFAULTS.dpi)),
    printScale: Math.max(0.90, Math.min(1.00, parseFloat(printScale.value||DEFAULTS.printScale)))
  };
  chrome.storage.sync.set(payload, () => {
    saveBtn.textContent = "Saved ✓";
    setTimeout(()=> saveBtn.textContent = "Save", 1200);
  });
});